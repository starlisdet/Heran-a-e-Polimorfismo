
public class Funcion�rio extends Pessoa {

	public Funcion�rio(String nome, String cpf, String endereco, int idade, int rg) {
		super(nome, cpf, endereco, idade, rg);
	}
	public String cargo;
	public double salario;
	
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
}
