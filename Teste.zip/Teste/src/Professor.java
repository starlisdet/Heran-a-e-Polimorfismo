
public class Professor extends Pessoa {

	public Professor(String nome, String cpf, String endereco, int idade, int rg) {
		super(nome, cpf, endereco, idade, rg);
	}
	public String disciplina;
	public double salario;

}
