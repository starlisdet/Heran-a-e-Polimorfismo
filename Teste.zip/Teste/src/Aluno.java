
public class Aluno extends Pessoa {

	public Aluno(String nome, String cpf, String endereco, int idade, int rg) {
		super(nome, cpf, endereco, idade, rg);
	}
	public String matricula;
	public String cod_aluno;
	
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getCod_aluno() {
		return cod_aluno;
	}
	public void setCod_aluno(String cod_aluno) {
		this.cod_aluno = cod_aluno;
	}
	
	

}
